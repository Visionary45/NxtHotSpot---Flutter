import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:fab_circular_menu/fab_circular_menu.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:nxthotspot/Directions.dart';

import 'package:nxthotspot/models/nearby_res.dart';

import 'Setiings.dart';

class MapViewWidget extends StatefulWidget {
  final String placeName;
  final double lng, lat;
  const MapViewWidget(
      {super.key,
      required this.placeName,
      required this.lat,
      required this.lng});

  @override
  _MapViewWidgetState createState() => _MapViewWidgetState();
}

class _MapViewWidgetState extends State<MapViewWidget> {
  BitmapDescriptor userMaker = BitmapDescriptor.defaultMarker;
  Results results = Results();

  late GoogleMapController googleMapController;
  Completer<GoogleMapController> _controller = Completer();
  late List<Results> res;
  late Future<List<Results>> dataResults;
  late Future<Position> currentPosition;

  String usrlat = '';
  String lng = '';
  double ratingValue = 0;

  void addCustomMarker() {
    BitmapDescriptor.fromAssetImage(
      const ImageConfiguration(size: Size(10, 10)),
      'assets/marker.png',
    ).then((icon) {
      userMaker = icon;
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    dataResults = getNearbyPlaces();
    usrlat = widget.lat.toString();
    currentPosition = _determinePosition();
    lng = widget.lng.toString();
    debugPrint(widget.placeName.toString());
    userPositionData();
    // ignore: prefer_interpolation_to_compose_strings
    debugPrint(widget.placeName + " Long + lat data " + usrlat + ' ' + lng);
    addCustomMarker();
    userPositionData();
  }

  String radius = "5000";
  String apiKey = 'AIzaSyCwo9KjQa6KIVkr0eam-Qx0It3suLu1jOc';
  String placeID = '';
  NearbyPlacesResponse nearbyPlacesResponse = NearbyPlacesResponse();

  double usrLat = 2229018829.09;
  // ignore: prefer_final_fields
  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(0.0, 0.0),
    zoom: 0,
  );

  Set<Marker> markers = {};
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: const Color(0x00FFFFFF),
        automaticallyImplyLeading: false,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Colors.white70),
              child: Image.asset(
                'assets/logo.png',
                height: 450,
                width: 200,
              ),
            ),
            ListTile(
              title: const Text('Settings'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: ((context) => const SettingsWidget()),
                  ),
                );
              },
            ),
            ListTile(
              title: const Text('Logout'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      body: Stack(
        children: <Widget>[_buildGoogleMaps(context), _mapContainer()],
      ),
      floatingActionButton: FabCircularMenu(
        alignment: Alignment.bottomRight,
        fabColor: Colors.blue.shade50,
        fabOpenColor: Colors.amber.shade100,
        ringDiameter: 150.0,
        ringWidth: 30.0,
        ringColor: Colors.blue.shade50,
        fabSize: 30,
        children: [
          IconButton(
            onPressed: () async {
              Position position = await _determinePosition();
              GoogleMapController controller = await _controller.future;
              controller.animateCamera(
                CameraUpdate.newCameraPosition(
                  CameraPosition(
                      target: LatLng(position.latitude, position.longitude),
                      zoom: 16),
                ),
              );
              markers.clear();
              markers.add(
                Marker(
                  // ignore: prefer_const_constructors
                  icon: userMaker,
                  markerId: const MarkerId("CurrentLoca"),
                  position: LatLng(position.latitude, position.longitude),
                ),
              );
              getNearbyPlaces();
              setState(() {});
            },
            icon: const Icon(Icons.location_searching),
          ),
          IconButton(
            onPressed: () {
              onPressed:
              () => scaffoldKey.currentState!.openDrawer();
            },
            icon: const Icon(Icons.menu),
          )
        ],
      ),
    );
  }

  Widget _buildGoogleMaps(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: GoogleMap(
        markers: markers,
        mapToolbarEnabled: false,
        zoomControlsEnabled: false,
        mapType: MapType.normal,
        onMapCreated: (GoogleMapController controller) {
          _controller.complete(controller);
        },
        initialCameraPosition: _kGooglePlex,
      ),
    );
  }

  Widget _mapContainer() {
    // ignore: avoid_unnecessary_containers
    return FutureBuilder<List<Results>>(
      future: dataResults,
      builder: (context, snapshot) {
        if (snapshot.data == null) {
          return const SizedBox(
            width: 0.0,
            height: 0.0,
          );
        } else if (snapshot.data!.isEmpty) {
          return const SizedBox(
            width: 0.0,
            height: 0.0,
          );
        } else {
          return ListView.builder(
            padding: EdgeInsets.zero,
            shrinkWrap: false,
            scrollDirection: Axis.horizontal,
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              return Container(
                alignment: Alignment(0.0, 0.7),
                padding: const EdgeInsets.all(0.5),
                margin: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Image.network(
                          snapshot.data![index].icon.toString(),
                          width: 80,
                          fit: BoxFit.cover,
                        ),
                        Container(
                          width: 180,
                          height: 100,
                          decoration:
                              BoxDecoration(color: Colors.blue.shade100),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Align(
                                alignment: const AlignmentDirectional(-0.8, 0),
                                child: Text(
                                  '${snapshot.data![index].name}',
                                  style: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Align(
                                alignment:
                                    const AlignmentDirectional(-0.8, 0.2),
                                child: Text(
                                  '${snapshot.data![index].types![0].toString()}',
                                  style: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w400),
                                ),
                              ),
                              Align(
                                alignment:
                                    const AlignmentDirectional(-0.8, 0.9),
                                child: RatingBar.builder(
                                  initialRating: 4,
                                  minRating: 0,
                                  itemSize: 20,
                                  itemCount: 5,
                                  allowHalfRating: true,
                                  updateOnDrag: false,
                                  itemPadding: const EdgeInsets.symmetric(
                                      horizontal: 4.0),
                                  itemBuilder: (context, index) => const Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                  ),
                                  glowColor: Colors.amber.shade50,
                                  onRatingUpdate: (rating) {
                                    print(rating);
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 98,
                          height: 100,
                          decoration:
                              const BoxDecoration(color: Colors.amberAccent),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Align(
                                alignment:
                                    const AlignmentDirectional(-0.45, -0.9),
                                child: IconButton(
                                  hoverColor: Colors.transparent,
                                  icon: const Icon(
                                    Icons.directions_rounded,
                                    size: 22,
                                  ),
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: ((context) => mapDirections(
                                              placeLat: snapshot.data![index]
                                                  .geometry!.location!.lat!
                                                  .toDouble(),
                                              placeLng: snapshot.data![index]
                                                  .geometry!.location!.lng!
                                                  .toDouble(),
                                              placeID: snapshot
                                                  .data![index].name
                                                  .toString(),
                                            )),
                                      ),
                                    );
                                    debugPrint('Directions Button Clicked ');
                                  },
                                ),
                              ),
                              Align(
                                alignment:
                                    const AlignmentDirectional(-0.45, -0.9),
                                child: IconButton(
                                  hoverColor: Colors.transparent,
                                  icon: const Icon(
                                    FontAwesomeIcons.heart,
                                    size: 22,
                                  ),
                                  onPressed: () {
                                    debugPrint('Favorite Button Clicked ');
                                  },
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    )
                  ],
                ),
              );
            },
          );
        }
      },
    );
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      return Future.error('Location Service are Disabled');
    }
    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permission denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error('Location Permission are permanently denied');
    }
    Position position = await Geolocator.getCurrentPosition();

    debugPrint("User Location Debug " + position.toString());
    return position;
  }

  Future<List<Results>> getNearbyPlaces() async {
    Position position = await _determinePosition();
    double lng = position.longitude;
    double lat = position.latitude;
    // ignore: prefer_interpolation_to_compose_strings
    var url = Uri.parse(
        // ignore: prefer_interpolation_to_compose_strings
        //https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=' + latitude.toString() + ','
        //+ longitude.toString() + '&radius=' + radius + '&key=' + apiKey
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${position.latitude},${position.longitude}&radius=5000&type=${widget.placeName.toString()}&key=AIzaSyCwo9KjQa6KIVkr0eam-Qx0It3suLu1jOc');

    var response = await http.post(url);

    nearbyPlacesResponse =
        NearbyPlacesResponse.fromJson(jsonDecode(response.body));

    setState(() {});
    // ignore: prefer_interpolation_to_compose_strings
    debugPrint(lat.toString() + " " + lng.toString());
    debugPrint(response.body);
    res = nearbyPlacesResponse.results!.toList();
    return res.toList();
  }

  Future<void> _gotoLocation() async {
    Position userPosition = await _determinePosition();
    final GoogleMapController gMapsController = await _controller.future;
    if (userPosition.latitude != null && userPosition.longitude != null) {
      gMapsController.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(
              target: LatLng(userPosition.altitude, userPosition.longitude),
              zoom: 5,
              tilt: 00)));
    }
  }

  Future<LatLng> userPositionData() async {
    Position userP = await _determinePosition();
    String latLong =
        userP.latitude.toString() + "," + userP.longitude.toString();
    // ignore: unused_local_variable
    Location location =
        Location(userP.latitude.toDouble(), userP.longitude.toDouble());
    LatLng userData =
        LatLng(userP.latitude.toDouble(), userP.longitude.toDouble());
    debugPrint(userData.toString());
    return userData;
  }
}
