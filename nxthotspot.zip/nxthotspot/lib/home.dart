// ignore_for_file: use_build_context_synchronously

import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:nxthotspot/Setiings.dart';
import 'models/searchString.dart';

import 'MapView.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final _unfocusNode = FocusNode();
  @override
  void initState() {
    super.initState();
    _determinePosition();
  }

//flutter draw to iconbutton  ontap?
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () => scaffoldKey.currentState!.openDrawer(),
          icon: const Icon(Icons.menu_rounded),
        ),
        title: const Text("Home"),
        centerTitle: true,
        elevation: 6,
        shadowColor: Colors.grey,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Colors.white70),
              child: Image.asset(
                'assets/logo.png',
                height: 450,
                width: 200,
              ),
            ),
            ListTile(
              title: const Text('Settings'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: ((context) => const SettingsWidget()),
                  ),
                );
              },
            ),
            ListTile(
              title: const Text('Logout'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).requestFocus(_unfocusNode),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              const SizedBox(
                height: 10,
              ),
              Expanded(
                child: DefaultTabController(
                  length: 2,
                  initialIndex: 0,
                  child: Column(
                    children: [
                      const TabBar(
                        labelColor: Colors.blueAccent,
                        indicatorColor: Colors.amber,
                        tabs: [
                          Tab(
                            text: 'Home',
                            icon: FaIcon(
                              FontAwesomeIcons.house,
                            ),
                          ),
                          Tab(
                            text: 'Favorites',
                            icon: FaIcon(FontAwesomeIcons.solidHeart),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 2,
                      ),
                      Expanded(
                        child: TabBarView(
                          children: [
                            Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                TextFormField(
                                  initialValue: '',
                                  decoration: const InputDecoration(
                                      hintText: 'Search Place Name',
                                      border: OutlineInputBorder(),
                                      prefixIcon:
                                          Icon(FontAwesomeIcons.searchengin)),
                                ),
                                const SizedBox(
                                  height: 4,
                                ),
                                Expanded(
                                  // ignore: avoid_unnecessary_containers
                                  child: Container(
                                    color: Colors.transparent,
                                    child: GridView(
                                      padding: EdgeInsets.zero,
                                      gridDelegate:
                                          const SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 2,
                                        crossAxisSpacing: 3,
                                        mainAxisSpacing: 3,
                                        childAspectRatio: 1.3,
                                      ),
                                      scrollDirection: Axis.vertical,
                                      children: [
                                        IconButton(
                                          style: IconButton.styleFrom(
                                              backgroundColor:
                                                  Colors.orangeAccent),
                                          onPressed: () async {
                                            Position p =
                                                await _determinePosition();
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: ((context) =>
                                                    MapViewWidget(
                                                      placeName: 'restaurant',
                                                      lat:
                                                          p.latitude.toDouble(),
                                                      lng:
                                                          p.latitude.toDouble(),
                                                    )),
                                              ),
                                            );
                                          },
                                          icon: const Icon(
                                            FontAwesomeIcons.utensils,
                                            size: 30,
                                            color: Colors.blueAccent,
                                          ),
                                        ),
                                        IconButton(
                                          style: IconButton.styleFrom(
                                              backgroundColor:
                                                  Colors.orangeAccent),
                                          onPressed: () async {
                                            Position p2 =
                                                await _determinePosition();
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: ((context) =>
                                                    MapViewWidget(
                                                      placeName: 'cafe',
                                                      lat: p2.altitude
                                                          .toDouble(),
                                                      lng: p2.longitude
                                                          .toDouble(),
                                                    )),
                                              ),
                                            );
                                          },
                                          icon: const Icon(
                                              FontAwesomeIcons.mugHot,
                                              size: 30,
                                              color: Colors.blueAccent),
                                        ),
                                        IconButton(
                                          style: IconButton.styleFrom(
                                              backgroundColor:
                                                  Colors.orangeAccent),
                                          onPressed: () async {
                                            Position p =
                                                await _determinePosition();
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: ((context) =>
                                                    MapViewWidget(
                                                      placeName: 'park',
                                                      lat:
                                                          p.altitude.toDouble(),
                                                      lng: p.longitude
                                                          .toDouble(),
                                                    )),
                                              ),
                                            );
                                          },
                                          icon: const Icon(
                                              FontAwesomeIcons.tree,
                                              size: 30,
                                              color: Colors.blueAccent),
                                        ),
                                        IconButton(
                                          style: IconButton.styleFrom(
                                              backgroundColor:
                                                  Colors.orangeAccent),
                                          onPressed: () async {
                                            Position p =
                                                await _determinePosition();
                                            var name = 'Restaurant';
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: ((context) =>
                                                    MapViewWidget(
                                                      placeName: 'bar',
                                                      lat:
                                                          p.altitude.toDouble(),
                                                      lng: p.longitude
                                                          .toDouble(),
                                                    )),
                                              ),
                                            );
                                          },
                                          icon: const Icon(
                                              FontAwesomeIcons.champagneGlasses,
                                              size: 30,
                                              color: Colors.blueAccent),
                                        ),
                                        IconButton(
                                          style: IconButton.styleFrom(
                                              backgroundColor:
                                                  Colors.orangeAccent),
                                          onPressed: () async {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: ((context) =>
                                                    const MapViewWidget(
                                                      placeName: 'store',
                                                      lat: 0,
                                                      lng: 0,
                                                    )),
                                              ),
                                            );
                                          },
                                          icon: const Icon(
                                              FontAwesomeIcons.bagShopping,
                                              size: 30,
                                              color: Colors.blueAccent),
                                        ),
                                        IconButton(
                                          style: IconButton.styleFrom(
                                              backgroundColor:
                                                  Colors.orangeAccent),
                                          onPressed: () async {
                                            Position p =
                                                await _determinePosition();
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: ((context) =>
                                                    MapViewWidget(
                                                      placeName: 'bus_station',
                                                      lat: p.altitude,
                                                      lng: p.longitude,
                                                    )),
                                              ),
                                            );
                                          },
                                          icon: const Icon(
                                              FontAwesomeIcons.taxi,
                                              size: 30,
                                              color: Colors.blueAccent),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            ListView(
                              padding: EdgeInsets.zero,
                              scrollDirection: Axis.vertical,
                              children: [
                                ListTile(
                                  leading: const FaIcon(
                                    FontAwesomeIcons.solidHeart,
                                  ),
                                  title: Text("Place Name"),
                                  subtitle: const Text("Location"),
                                  trailing: const Icon(
                                    Icons.arrow_forward_ios,
                                    color: Color(0xFF303030),
                                    size: 20,
                                  ),
                                  tileColor: const Color(0xFFF5F5F5),
                                  dense: false,
                                  onTap: (() async {
                                    Position p = await _determinePosition();
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: ((context) => MapViewWidget(
                                              placeName: 'Restaurants',
                                              lat: p.altitude,
                                              lng: p.longitude,
                                            )),
                                      ),
                                    );
                                  }),
                                ),
                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      return Future.error('Location Service are Disabled');
    }
    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permission denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error('Location Permission are permanently denied');
    }
    Position position = await Geolocator.getCurrentPosition();
    var l;
    debugPrint("User Location Debug " + position.toString());
    return position;
  }
}
