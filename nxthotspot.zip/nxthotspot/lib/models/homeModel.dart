/*body: 
      Container(
        child: GoogleMap(
          markers: markers,
          mapToolbarEnabled: false,
          zoomControlsEnabled: false,
          mapType: MapType.normal,
          onMapCreated: (GoogleMapController controller) {
            googleMapController = controller;
          },
          initialCameraPosition: _kGooglePlex,
          //flutter log?
        ),
      ),
      floatingActionButton: FabCircularMenu(
        alignment: Alignment.bottomRight,
        fabColor: Colors.blue.shade50,
        fabOpenColor: Colors.amber.shade100,
        ringDiameter: 250.0,
        ringWidth: 60.0,
        ringColor: Colors.blue.shade50,
        fabSize: 60,
        children: [
          IconButton(
            onPressed: () async {
              Position position = await _determinePosition();
              googleMapController.animateCamera(
                CameraUpdate.newCameraPosition(
                  CameraPosition(
                      target: LatLng(position.latitude, position.longitude),
                      zoom: 16),
                ),
              );
              markers.clear();
              markers.add(
                Marker(
                  // ignore: prefer_const_constructors
                  icon: userMaker,
                  markerId: const MarkerId("CurrentLoca"),
                  position: LatLng(position.latitude, position.longitude),
                ),
              );
              getNearbyPlaces();
              setState(() {});
            },
            icon: const Icon(Icons.location_searching),
          ),
          //flutter google maps custom marker?

          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.menu),
          )
        ],
      ),



              children: [
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Image.network(
                'https://picsum.photos/seed/693/600',
                width: 80,
                height: 100,
                fit: BoxFit.cover,
              ),
              Container(
                width: 180,
                height: 100,
                decoration: BoxDecoration(color: Colors.blue.shade100),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Align(
                      alignment: const AlignmentDirectional(-0.8, 0),
                      child: Text(
                        '${results.name != null}',
                        style: const TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Align(
                      alignment: const AlignmentDirectional(-0.8, 0.2),
                      child: Text(
                        '${results.vicinity != null}',
                        style: const TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.w400),
                      ),
                    ),
                    Align(
                      alignment: const AlignmentDirectional(-0.8, 0.9),
                      child: RatingBar.builder(
                        initialRating: 3,
                        minRating: 0,
                        itemSize: 20,
                        itemCount: 5,
                        allowHalfRating: true,
                        itemPadding:
                            const EdgeInsets.symmetric(horizontal: 4.0),
                        itemBuilder: (context, index) => const Icon(
                          Icons.star,
                          color: Colors.amber,
                        ),
                        glowColor: Colors.amber.shade50,
                        onRatingUpdate: (rating) {
                          print(rating);
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 98,
                height: 100,
                decoration: const BoxDecoration(color: Colors.amberAccent),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Align(
                      alignment: const AlignmentDirectional(-0.45, -0.9),
                      child: IconButton(
                        hoverColor: Colors.transparent,
                        icon: const Icon(
                          Icons.directions_rounded,
                          size: 22,
                        ),
                        onPressed: () {
                          debugPrint('Directions Button Clicked ');
                        },
                      ),
                    ),
                    Align(
                      alignment: const AlignmentDirectional(-0.45, -0.9),
                      child: IconButton(
                        hoverColor: Colors.transparent,
                        icon: const Icon(
                          FontAwesomeIcons.heart,
                          size: 22,
                        ),
                        onPressed: () {
                          debugPrint('Favorite Button Clicked ');
                        },
                      ),
                    ),
                  ],
                ),
              )
            ],
          )
        ],
      */

      //flutter futurebuilder?