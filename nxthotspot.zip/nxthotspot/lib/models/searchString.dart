class SearchString {
  final String placeName;
  const SearchString(this.placeName);
}
