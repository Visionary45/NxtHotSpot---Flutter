// ignore_for_file: unrelated_type_equality_checks

import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:http/http.dart' as http;
import 'package:geocoding/geocoding.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:nxthotspot/models/directionsResponse.dart';

class mapDirections extends StatefulWidget {
  final String placeID;
  final double placeLng, placeLat;
  const mapDirections(
      {super.key,
      required this.placeID,
      required this.placeLng,
      required this.placeLat});

  @override
  _mapDirectionsWidgetState createState() => _mapDirectionsWidgetState();
}

class _mapDirectionsWidgetState extends State<mapDirections> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  Completer<GoogleMapController> googleMapController = Completer();

  String totalDistance = "";
  String totalTime = "";
  String startDestination = "";
  String endDestination = "";
  LatLng origin = const LatLng(999090, 0918375281);
  LatLng destination = const LatLng(902785, 1273465783);

  late Future<Position> currentPosition;

  int? _selectedIndex;

  final List<Data> _choiceChipList = [
    Data('Walking', const Icon(Icons.nordic_walking), Colors.blue),
    Data('Car', const Icon(FontAwesomeIcons.carSide), Colors.green.shade50),
    Data('Train', const Icon(Icons.train), Colors.orange.shade50),
    Data('Bike', const Icon(FontAwesomeIcons.motorcycle), Colors.pink.shade50),
  ];
  BitmapDescriptor userMaker = BitmapDescriptor.defaultMarker;

  String radius = "5000";
  String apiKey = 'AIzaSyCwo9KjQa6KIVkr0eam-Qx0It3suLu1jOc';
  String placeID = '';
  DirectionsResponse _directionsResponse = DirectionsResponse();
  Set<Polyline> polylinePoint = {};
  late List<Routes> resultD;
  late Future<List<Routes>> routData;

  // ignore: prefer_final_fields
  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(0.0, 0.0),
    zoom: 0,
  );

  void addCustomMarker() {
    BitmapDescriptor.fromAssetImage(
      const ImageConfiguration(size: Size(10, 10)),
      'assets/marker.png',
    ).then((icon) {
      userMaker = icon;
    });
  }

  Set<Marker> markers = {};
  @override
  void initState() {
    super.initState();
    _determinePosition();
    routData = drawPolylines();
    // ignore: prefer_interpolation_to_compose_strings
    debugPrint('Detail from MapView ' +
        widget.placeLat.toDouble().toString() +
        " " +
        widget.placeLng.toDouble().toString() +
        " " +
        widget.placeID.toString());
    drawPolylines();
    addCustomMarker();
    if (googleMapController.isCompleted == true) {
      _gotoLocation(widget.placeLat, widget.placeLng);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: const Color(0x00FFFFFF),
        leading: const Icon(Icons.arrow_back_ios),
        actions: [],
        elevation: 6,
      ),
      body: Stack(children: <Widget>[
        draggableBottomSheet(),
        _buildGoogleMaps(context),
        Container(
          margin: const EdgeInsets.all(5),
          padding: const EdgeInsets.all(10),
          color: Colors.amber.shade100,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                readOnly: true,
                initialValue: startDestination,
                decoration: const InputDecoration(
                    suffixIcon: Icon(FontAwesomeIcons.ellipsis),
                    hintText: '',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.location_searching)),
              ),
              const SizedBox(
                height: 3,
              ),
              TextFormField(
                readOnly: true,
                initialValue: widget.placeID.toString(),
                decoration: const InputDecoration(
                  suffixIcon: Icon(Icons.swap_vert),
                  hintText: '',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.location_on),
                ),
              ),
            ],
          ),
        ),
      ]),
      /*
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _showBottomSheet(context),
          label: const Text("Show Steps"),
          icon: const Icon(Icons.directions),
        ),*/
    );
  }

  void _showBottomSheet(BuildContext context) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        isDismissible: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(15)),
        ),
        builder: (context) => DraggableScrollableSheet(
              initialChildSize: 0.1,
              minChildSize: 0.1,
              maxChildSize: 0.5,
              expand: false,
              builder: (context, scrollController) => SafeArea(
                  child: ListView.builder(
                controller: scrollController,
                itemCount: resultD.length,
                itemBuilder: ((context, index) {
                  return Container(
                    child: draggableBottomSheet(),
                  );
                }),
              )),
            ));
  }

  Widget _buildGoogleMaps(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: GoogleMap(
        polylines: polylinePoint,
        zoomControlsEnabled: false,
        markers: markers,
        initialCameraPosition: _kGooglePlex,
        mapType: MapType.normal,
        onMapCreated: (controller) {
          googleMapController.complete(controller);
        },
      ),
    );
  }

  Widget _textEditors() {
    return Container(
      height: 120,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          TextFormField(
            initialValue: '',
            decoration: const InputDecoration(
                hintText: 'Start Destination',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_searching)),
          ),
          TextFormField(
              initialValue: '',
              decoration: const InputDecoration(
                  hintText: 'End Destination',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.location_on))),
        ],
      ),
    );
  }

  Widget showListData() {
    return FutureBuilder<List<Routes>>(
      future: routData,
      builder: (context, snapshot) {
        if (snapshot.data == null) {
          return const SizedBox(
            width: 0.0,
            height: 0.0,
          );
        } else if (snapshot.data!.isEmpty) {
          return const SizedBox(
            width: 0.0,
            height: 0.0,
          );
        } else {
          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: ((context, index) {
              if (snapshot.data![index] == 0) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      const SizedBox(
                        width: 50,
                        child: Divider(thickness: 50),
                      ),
                      Text(
                        "The total Distance to Destination: $totalDistance",
                        style: const TextStyle(
                            fontSize: 20,
                            color: Colors.amberAccent,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "The total Time to Destination: $totalTime",
                        style: const TextStyle(
                            fontSize: 20,
                            color: Colors.amberAccent,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                );
              }
              return ClipRRect(
                child: Card(
                  elevation: 0,
                  child: ListTile(
                    onTap:
                        () {}, //directionsResponse.routes![0].legs![0].steps![i].polyline!.points!
                    title: Text(snapshot.data![index].legs![index].steps![index]
                        .polyline!.points!
                        .toString()),
                    leading: const Icon(Icons.place_sharp),
                    trailing: Text(
                        snapshot.data![index].legs![index].steps!.toString()),
                  ),
                ),
              );
            }),
          );
        }
      },
    );
  }

  Widget draggableBottomSheet() {
    return DraggableScrollableSheet(
      initialChildSize: 0.1,
      minChildSize: 0.1,
      maxChildSize: 0.5,
      builder: (context, scrollController) {
        return Container(
            child: FutureBuilder<List<Routes>>(
          future: routData,
          builder: (context, snapshot) {
            if (snapshot.data == null) {
              return const SizedBox(
                width: 0.0,
                height: 0.0,
              );
            } else if (snapshot.data!.isEmpty) {
              return const SizedBox(
                width: 0.0,
                height: 0.0,
              );
            } else {
              return ListView.builder(
                  controller: scrollController,
                  itemCount: resultD.length,
                  itemBuilder: (context, index) {
                    final resRes = resultD[index];
                    if (index == 0) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            const SizedBox(
                              width: 50,
                              child: Divider(thickness: 50),
                            ),
                            Text(
                              "The total Distance to Destination: $totalDistance",
                              style: const TextStyle(
                                  fontSize: 20,
                                  color: Colors.amberAccent,
                                  fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "The total Time to Destination: $totalTime",
                              style: const TextStyle(
                                  fontSize: 20,
                                  color: Colors.amberAccent,
                                  fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      );
                    }
                    return ClipRRect(
                      child: Card(
                        elevation: 0,
                        child: ListTile(
                          onTap: () {},
                          title: const Text("Place"),
                          leading: const Icon(Icons.place_sharp),
                          trailing: const Text("Steps"),
                        ),
                      ),
                    );
                  });
            }
          },
        ));
      },
    );
  }

  List<Widget> choiceChip() {
    List<Widget> chips = [];
    for (int i = 0; i < _choiceChipList.length; i++) {
      Widget item = Padding(
        padding: const EdgeInsets.only(
          left: 4,
        ),
        child: ChoiceChip(
          avatar: _choiceChipList[i].icon,
          label: Text(_choiceChipList[i].label),
          labelStyle: const TextStyle(color: Colors.white),
          backgroundColor: _choiceChipList[i].color,
          selected: _selectedIndex == i,
          onSelected: (bool value) {
            setState(() {
              _selectedIndex = i;
            });
          },
        ),
      );
      chips.add(item);
    }
    return chips;
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      return Future.error('Location Service are Disabled');
    }
    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permission denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error('Location Permission are permanently denied');
    }
    Position position = await Geolocator.getCurrentPosition();

    debugPrint("User Location Debug $position");
    return position;
  }

  Future<void> _gotoLocation(double latD, double lngD) async {
    Position userPosition = await _determinePosition();
    final GoogleMapController gMapsController =
        await googleMapController.future;
    gMapsController.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(target: LatLng(latD, lngD), zoom: 12.9, tilt: 11)));
    debugPrint(userPosition.latitude.toString());
  }

  Future<List<Routes>> drawPolylines() async {
    Position userPosition = await _determinePosition();

    var res = await http.post(Uri.parse(
        "https://maps.googleapis.com/maps/api/directions/json?key=$apiKey&units=metric&origin=${userPosition.latitude},${userPosition.longitude}&destination=${widget.placeLat.toDouble()},${widget.placeLng.toDouble()}&mode=driving"));

    debugPrint(res.body);
    _directionsResponse = DirectionsResponse.fromJson(jsonDecode(res.body));

    totalTime = _directionsResponse.routes![0].legs![0].distance!.text!;
    totalDistance = _directionsResponse.routes![0].legs![0].duration!.text!;

    startDestination =
        _directionsResponse.routes![0].legs![0].startAddress.toString();
    debugPrint("Start Destination $startDestination $totalTime");
    endDestination =
        _directionsResponse.routes![0].legs![0].endAddress.toString();

/*
    List<Placemark> placemark = await placemarkFromCoordinates(
        userPosition.altitude, userPosition.longitude);
    startDestination = placemark.toList().toString(); */

    markers.add(
      Marker(
        icon: userMaker,
        markerId: const MarkerId("CurrentLocation"),
        position: LatLng(userPosition.latitude, userPosition.longitude),
      ),
    );
    markers.add(
      Marker(
        markerId: const MarkerId("CurrentLoca"),
        position: LatLng(widget.placeLat, widget.placeLng),
      ),
    );
    _gotoLocation(widget.placeLat, widget.placeLng);

    for (int i = 0;
        i < _directionsResponse.routes![0].legs![0].steps!.length;
        i++) {
      polylinePoint.add(Polyline(
          polylineId: PolylineId(_directionsResponse
              .routes![0].legs![0].steps![i].polyline!.points!),
          points: [
            LatLng(
                _directionsResponse
                    .routes![0].legs![0].steps![i].startLocation!.lat!,
                _directionsResponse
                    .routes![0].legs![0].steps![i].startLocation!.lng!),
            LatLng(
                _directionsResponse
                    .routes![0].legs![0].steps![i].endLocation!.lat!,
                _directionsResponse
                    .routes![0].legs![0].steps![i].endLocation!.lng!),
          ],
          width: 3,
          color: Colors.red));
    }
    setState(() {});
    return resultD = _directionsResponse.routes!.toList();
  }
}

class Data {
  String label;
  Icon icon;
  Color color;
  Data(this.label, this.icon, this.color);
}
            /*
          ListView.builder(
            controller: scrollController,
            itemCount: resultD.length,
            itemBuilder: (context, index) {
              final resRes = resultD[index];
              if (index == 0) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: const [
                      Text("Total Distance"),
                      Text("Time taken"),
                    ],
                  ),
                );
              }
              return ClipRRect(
                child: Card(
                  elevation: 0,
                  child: ListTile(
                    onTap: () {},
                    title: const Text("Place"),
                    leading: const Icon(Icons.place_sharp),
                    trailing: const Text("Steps"),
                  ),
                ),
              );
            },
          ),
          */