import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SettingsWidget extends StatefulWidget {
  const SettingsWidget({super.key});
  @override
  _SettingWidgetState createState() => _SettingWidgetState();
}

class _SettingWidgetState extends State<SettingsWidget> {
  bool _themeOption = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        //flutter text style?
        title: const Text(
          'Settings',
          style: TextStyle(fontFamily: 'Poppins', fontSize: 22),
        ),
        elevation: 6,
        shadowColor: Colors.grey,
      ),
      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          const SizedBox(
            height: 5,
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(20, 0, 20, 0),
            child: Row(
              children: const [
                Expanded(
                    child: Text("Choose Theme Type below, on Light by Default"))
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(0, 12, 0, 0),
            child: SwitchListTile(
                title: const Text('Enable Theme'),
                value: _themeOption,
                onChanged: (bool value) {
                  setState(() {
                    _themeOption = value;
                  });
                }),
          ),
        ],
      ),
    );
  }
}
